# Time Capsule App

A Python desktop app using Tkinter that allows users to create "time capsules" — messages scheduled for future release. Messages are saved in a MySQL database and a CSV file.

## Features

- GUI to input name, message, and release date
- Stores messages in MySQL and CSV
- Retrieves messages whose release time has passed

## Requirements

- Python 3.x
- MySQL server
- Python packages: tkinter, mysql-connector-python, pandas

## Setup

1. Install Python dependencies:

```bash
pip install -r requirements.txt
```

2. Set up MySQL:

```sql
CREATE DATABASE time_capsule_ai;
USE time_capsule_ai;

CREATE TABLE capsules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255),
    message TEXT,
    summary TEXT,
    timestamp DATETIME,
    release_date DATETIME
);
```

3. Update your MySQL credentials in `time_capsule_app.py` under `DB_CONFIG`.

4. Run the application:

```bash
python time_capsule_app.py
```

## Notes

- The app uses a local CSV file (`time_capsule_entries.csv`) for backup logging.
- Replace `'your_password'` in the code with your actual MySQL password.
